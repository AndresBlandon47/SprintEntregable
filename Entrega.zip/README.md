Para la ejecución por nodemon usar el comando:


nodemon -e hbs,js